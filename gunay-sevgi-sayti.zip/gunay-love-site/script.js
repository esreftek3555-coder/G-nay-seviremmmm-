// Create floating hearts
const heartsContainer = document.getElementById('hearts');
const heartEmojis = ['❤️', '💕', '💖', '💗', '🤍', '💓', '💞', '💝'];

function createHeart() {
    const heart = document.createElement('div');
    heart.classList.add('heart');
    heart.textContent = heartEmojis[Math.floor(Math.random() * heartEmojis.length)];
    
    // Random position and size
    const left = Math.random() * 100;
    const size = 14 + Math.random() * 22;
    const duration = 7 + Math.random() * 10;
    const delay = Math.random() * 5;
    
    heart.style.left = left + '%';
    heart.style.fontSize = size + 'px';
    heart.style.animationDuration = duration + 's';
    heart.style.animationDelay = delay + 's';
    
    // Slight horizontal drift
    const drift = (Math.random() - 0.5) * 60;
    heart.style.setProperty('--drift', drift + 'px');
    
    heartsContainer.appendChild(heart);
    
    // Remove after animation
    setTimeout(() => {
        heart.remove();
    }, (duration + delay) * 1000);
}

// Continuous hearts
function spawnHearts() {
    createHeart();
    setTimeout(spawnHearts, 400 + Math.random() * 600);
}

// Initial burst
for (let i = 0; i < 12; i++) {
    setTimeout(createHeart, i * 200);
}
spawnHearts();

// Sparkles
const sparklesContainer = document.getElementById('sparkles');

function createSparkle() {
    const sparkle = document.createElement('div');
    sparkle.classList.add('sparkle');
    
    sparkle.style.left = Math.random() * 100 + '%';
    sparkle.style.top = Math.random() * 100 + '%';
    sparkle.style.animationDuration = (1.5 + Math.random() * 2) + 's';
    sparkle.style.animationDelay = Math.random() * 2 + 's';
    
    const size = 2 + Math.random() * 4;
    sparkle.style.width = size + 'px';
    sparkle.style.height = size + 'px';
    
    sparklesContainer.appendChild(sparkle);
    
    setTimeout(() => sparkle.remove(), 4000);
}

setInterval(createSparkle, 300);

// Music player
const playBtn = document.getElementById('playBtn');
const bgMusic = document.getElementById('bgMusic');
const musicPlayer = document.getElementById('musicPlayer');
let isPlaying = false;

playBtn.addEventListener('click', () => {
    if (isPlaying) {
        bgMusic.pause();
        playBtn.classList.remove('playing');
        playBtn.querySelector('.play-icon').textContent = '♪';
        isPlaying = false;
    } else {
        // Try to play
        const playPromise = bgMusic.play();
        
        if (playPromise !== undefined) {
            playPromise
                .then(() => {
                    playBtn.classList.add('playing');
                    playBtn.querySelector('.play-icon').textContent = '❚❚';
                    isPlaying = true;
                })
                .catch(error => {
                    // No music file or autoplay blocked
                    alert('Musiqi faylı tapılmadı.\n\nZəhmət olmasa "music.mp3" adlı sevgi mahnısını bu qovluğa əlavə edin və səhifəni yeniləyin.');
                    console.log('Music play error:', error);
                });
        }
    }
});

// Optional: pause when tab is hidden
document.addEventListener('visibilitychange', () => {
    if (document.hidden && isPlaying) {
        bgMusic.pause();
        playBtn.classList.remove('playing');
        playBtn.querySelector('.play-icon').textContent = '♪';
        isPlaying = false;
    }
});

// Add a soft entrance animation to paragraphs
document.addEventListener('DOMContentLoaded', () => {
    const paragraphs = document.querySelectorAll('.letter p');
    paragraphs.forEach((p, i) => {
        p.style.opacity = '0';
        p.style.transform = 'translateY(20px)';
        p.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
        
        setTimeout(() => {
            p.style.opacity = '1';
            p.style.transform = 'translateY(0)';
        }, 1000 + i * 350);
    });
});
