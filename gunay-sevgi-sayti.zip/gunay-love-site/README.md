# Günay 🤍 — Sevgi Saytı

Romantik, animasiyalı sevgi səhifəsi.

## Xüsusiyyətlər
- Gözəl floating ürəklər animasiyası
- Soft sparkle effektləri
- Romantik gradient fon
- 27.09 — ∞ tarixi
- Tam mətn məktubu
- Musiqi pleyeri (öz mahnını əlavə et)

## İstifadə

1. `music.mp3` adlı sevdiyiniz mahnını bu qovluğa əlavə edin (istəyə bağlı)
2. `index.html` faylını brauzerdə açın
3. GitHub Pages üçün:
   - Bu qovluğu yeni GitHub repo-ya yükləyin
   - Settings → Pages → Source: Deploy from a branch → main / root

## Fayllar
- `index.html` — əsas səhifə
- `style.css` — stillər və animasiyalar
- `script.js` — ürəklər, sparkles və musiqi
- `music.mp3` — (özünüz əlavə edin)

Yaradıldı sevgi ilə 🤍
